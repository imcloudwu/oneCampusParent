# com.revivalx.container
This source code provides example to link two view controllers into one container view and switch between them using segmented control.

##SETUP/USAGE/HOWTO
Source code tutorial: http://blog.revivalx.com/2015/04/14/link-multiple-view-controllers-into-one-container-view-and-switch-between-them-using-segmented-control-using-swift/.

##FAQ/CONTACT/TROUBLESHOOT
Mohammad Nurdin bin Norazan

- http://github.com/datomnurdin
- http://twitter.com/datomnurdin
- mohammadnrdn@gmail.com
